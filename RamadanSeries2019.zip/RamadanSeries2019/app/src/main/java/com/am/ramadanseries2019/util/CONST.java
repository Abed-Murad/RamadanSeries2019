package com.am.ramadanseries2019.util;

public interface CONST {

    String BASE_YOUTUBE_URL = "http://www.youtube.com/watch?v=";

    String TEST_VIDEO_ID = "wA38GCX4Tb0";


}
